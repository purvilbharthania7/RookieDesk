namespace RookieDesk.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Admins",
                c => new
                    {
                        adminId = c.Int(nullable: false, identity: true),
                        emailId = c.String(),
                        password = c.String(),
                        name = c.String(),
                        branch = c.String(),
                        sem = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.adminId);
            
            CreateTable(
                "dbo.Answers",
                c => new
                    {
                        answerId = c.Int(nullable: false, identity: true),
                        answer = c.String(),
                        votes = c.Int(nullable: false),
                        Admin_adminId = c.Int(),
                        Question_questionId = c.Int(),
                    })
                .PrimaryKey(t => t.answerId)
                .ForeignKey("dbo.Admins", t => t.Admin_adminId)
                .ForeignKey("dbo.Questions", t => t.Question_questionId)
                .Index(t => t.Admin_adminId)
                .Index(t => t.Question_questionId);
            
            CreateTable(
                "dbo.Questions",
                c => new
                    {
                        questionId = c.Int(nullable: false, identity: true),
                        userId = c.Int(nullable: false),
                        question = c.String(),
                        votes = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.questionId)
                .ForeignKey("dbo.Users", t => t.userId, cascadeDelete: true)
                .Index(t => t.userId);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        userId = c.Int(nullable: false, identity: true),
                        email = c.String(),
                        password = c.String(),
                        name = c.String(),
                        branch = c.String(),
                        sem = c.Int(nullable: false),
                        Blocked_blockedId = c.Int(),
                    })
                .PrimaryKey(t => t.userId)
                .ForeignKey("dbo.Blockeds", t => t.Blocked_blockedId)
                .Index(t => t.Blocked_blockedId);
            
            CreateTable(
                "dbo.Blockeds",
                c => new
                    {
                        blockedId = c.Int(nullable: false, identity: true),
                        timeStamp = c.Long(nullable: false),
                    })
                .PrimaryKey(t => t.blockedId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Users", "Blocked_blockedId", "dbo.Blockeds");
            DropForeignKey("dbo.Questions", "userId", "dbo.Users");
            DropForeignKey("dbo.Answers", "Question_questionId", "dbo.Questions");
            DropForeignKey("dbo.Answers", "Admin_adminId", "dbo.Admins");
            DropIndex("dbo.Users", new[] { "Blocked_blockedId" });
            DropIndex("dbo.Questions", new[] { "userId" });
            DropIndex("dbo.Answers", new[] { "Question_questionId" });
            DropIndex("dbo.Answers", new[] { "Admin_adminId" });
            DropTable("dbo.Blockeds");
            DropTable("dbo.Users");
            DropTable("dbo.Questions");
            DropTable("dbo.Answers");
            DropTable("dbo.Admins");
        }
    }
}
