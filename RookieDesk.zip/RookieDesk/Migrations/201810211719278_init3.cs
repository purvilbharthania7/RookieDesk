namespace RookieDesk.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class init3 : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Questions", "votes");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Questions", "votes", c => c.Int(nullable: false));
        }
    }
}
