namespace RookieDesk.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class init2 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Answers", "Admin_adminId", "dbo.Admins");
            DropForeignKey("dbo.Answers", "Question_questionId", "dbo.Questions");
            DropIndex("dbo.Answers", new[] { "Admin_adminId" });
            DropIndex("dbo.Answers", new[] { "Question_questionId" });
            RenameColumn(table: "dbo.Answers", name: "Admin_adminId", newName: "adminId");
            RenameColumn(table: "dbo.Answers", name: "Question_questionId", newName: "questionId");
            AddColumn("dbo.Blockeds", "userId", c => c.Int(nullable: false));
            AlterColumn("dbo.Answers", "adminId", c => c.Int(nullable: false));
            AlterColumn("dbo.Answers", "questionId", c => c.Int(nullable: false));
            CreateIndex("dbo.Answers", "adminId");
            CreateIndex("dbo.Answers", "questionId");
            AddForeignKey("dbo.Answers", "adminId", "dbo.Admins", "adminId", cascadeDelete: true);
            AddForeignKey("dbo.Answers", "questionId", "dbo.Questions", "questionId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Answers", "questionId", "dbo.Questions");
            DropForeignKey("dbo.Answers", "adminId", "dbo.Admins");
            DropIndex("dbo.Answers", new[] { "questionId" });
            DropIndex("dbo.Answers", new[] { "adminId" });
            AlterColumn("dbo.Answers", "questionId", c => c.Int());
            AlterColumn("dbo.Answers", "adminId", c => c.Int());
            DropColumn("dbo.Blockeds", "userId");
            RenameColumn(table: "dbo.Answers", name: "questionId", newName: "Question_questionId");
            RenameColumn(table: "dbo.Answers", name: "adminId", newName: "Admin_adminId");
            CreateIndex("dbo.Answers", "Question_questionId");
            CreateIndex("dbo.Answers", "Admin_adminId");
            AddForeignKey("dbo.Answers", "Question_questionId", "dbo.Questions", "questionId");
            AddForeignKey("dbo.Answers", "Admin_adminId", "dbo.Admins", "adminId");
        }
    }
}
