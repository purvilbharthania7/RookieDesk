﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RookieDesk.Models;

namespace RookieDesk.Controllers
{
   
    public class LoginController : Controller
    {
        RookieDeskContext db = new RookieDeskContext();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(User u)
        {
            var isUser = (from m in db.User where u.email.Equals(m.email) && u.password.Equals(m.password) select m).SingleOrDefault();

            if (isUser == null)
            {
                var isAdmin = (from m in db.Admin where u.email.Equals(m.emailId) && u.password.Equals(m.password) select m).SingleOrDefault();

                if (isAdmin == null)
                {
                    ViewBag.loginStatus = "Invalid username or password";
                    return View();//login
                }

                int adminId = (from m in db.Admin where u.email.Equals(m.emailId) select m.adminId).SingleOrDefault();
                Session["id"] = adminId;
                Session["name"] = (from m in db.Admin where m.adminId == adminId select m.name).SingleOrDefault();
                Session["email"] = u.email;
                Session["role"] = "admin";
                
                Response.Redirect("/Admin/Index");
                return View();//Admin site
            }

            int userId = (from m in db.User where u.email.Equals(m.email) select m.userId).SingleOrDefault();
            Blocked blocked = (from m in db.Blocked where m.userId == userId select m).SingleOrDefault();

            long currentTimeStamp = (long)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;

            if(blocked != null && currentTimeStamp<= blocked.timeStamp)
            {
                ViewBag.loginStatus= "You are still blocked for less than: "+(int)((blocked.timeStamp-currentTimeStamp)/(24*3600)+1)+" days!";
                return View();
            }

            else if(blocked != null && currentTimeStamp > blocked.timeStamp)
            {
                db.Blocked.Remove(blocked);
                db.SaveChanges();
            }

            Session["id"] = userId;
            Session["name"] = (from m in db.User where m.userId == userId select m.name).SingleOrDefault();
            Session["email"] = u.email;
            Session["role"] = "user";
            
            Response.Redirect("/User/Index");
            return View();//user site
        }

        public void Logout()
        {
            if (Session["id"] != null)
            {
                Session.Abandon();
                Response.Redirect("/Login/Index");
            }
            else
            {
                Response.Redirect("/Home/Index");
            }
        }
    }
}