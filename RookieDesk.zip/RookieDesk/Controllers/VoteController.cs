﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RookieDesk.Models;

namespace RookieDesk.Controllers
{
    public class VoteController : Controller
    {

        RookieDeskContext db = new RookieDeskContext();

        public void Plus()
        {
            if (Session["id"] != null && (string)Session["role"] == "user")
            {
                int answerId = int.Parse(Request["aid"]);

                Answer ans = (from m in db.Answers where m.answerId == answerId select m).FirstOrDefault();

                ans.votes += 1;
                db.SaveChanges();

                Response.Redirect("/User/Index");
            }
            else
            {
                Response.Redirect("/Login/Index");
            }
        }

        public void Minus()
        {
            if (Session["id"] != null && (string)Session["role"]=="user")
            {

                int answerId = int.Parse(Request["aid"]);

                Answer ans = (from m in db.Answers where m.answerId == answerId select m).FirstOrDefault();

                ans.votes -= 1;
                db.SaveChanges();

                Response.Redirect("/User/Index");
            }

            else
            {
                Response.Redirect("/Login/Index");
            }
        }
    }
}