﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RookieDesk.Models;

namespace RookieDesk.Controllers
{
    public class AdminController : Controller
    {
        RookieDeskContext db = new RookieDeskContext();
        // GET: Answer
        public ActionResult Index()
        {
            if (Session["id"] != null && (string)Session["role"] == "admin")
                return View(db.Questions.OrderByDescending(m => m.questionId).ToList());

            Response.Redirect("/Login/Index");
            return View(db.Questions.ToList());
        }

        [HttpPost]
        public ActionResult Index(Answer a)
        {
            if (Session["id"] != null && (string)Session["role"] == "admin")
            {
                a.adminId = (int)Session["id"];
                a.votes = 0;
                a.questionId = int.Parse(Request["qid"]);

                db.Answers.Add(a);
                        
                db.SaveChanges();

                return View(db.Questions.OrderByDescending(m => m.questionId).ToList());
            }

            Response.Redirect("/Login/Index");
            return View();
        }

        public ActionResult AddAdmin()
        {
            if(Session["id"]!=null && (int)Session["id"] == 1 && (string)Session["role"] == "admin")
                return View();

            Response.Redirect("/Login/Index");
            return View();
        }

        [HttpPost]
        public ActionResult AddAdmin(Admin a)
        {
            if(Session["id"] != null && (int)Session["id"] == 1 && (string)Session["role"] == "admin")
            {
                db.Admin.Add(a);
                db.SaveChanges();
                ViewBag.addStatus = "Added Successfully!";

                return View();
            }

            Response.Redirect("/Login/Index");
            return View();
        }
        
        [HttpPost]
        public void BlockUser()
        {
            if (Session["id"] != null && (string)Session["role"] == "admin")
            {
                int userId = int.Parse(Request["uid"]);
                int questionId = int.Parse(Request["qid"]);
                int days = int.Parse(Request["days"]);

                long currentTimeStamp = (long)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                
                Blocked blocked = (from m in db.Blocked where m.userId == userId select m).SingleOrDefault();

                if (blocked != null)
                {
                    currentTimeStamp += Math.Max(days*24*3600,blocked.timeStamp-currentTimeStamp);
                }
                else
                {
                    currentTimeStamp += (days*24*3600);
                }

                Blocked b = new Blocked();

                b.userId = userId;
                b.timeStamp = currentTimeStamp;

                db.Blocked.Add(b);

                Question q = (from m in db.Questions where m.questionId==questionId select m ).FirstOrDefault();
                db.Questions.Remove(q);

                db.SaveChanges();

                Response.Redirect("/Admin/Index");
            }
            else
            {
                Response.Redirect("/Login/Index");
            }   
        }

        public ActionResult Profile()
        {
            if (Session["id"] != null && (string)Session["role"] == "admin")
            {
                int adminId = (int)Session["id"];

                ViewBag.admin = (from m in db.Admin where m.adminId == adminId select m).SingleOrDefault();

                return View();
            }

            Response.Redirect("/Login/Index");
            return View();
        }

        [HttpPost]
        public ActionResult Profile(Admin a)
        {

            if (Session["id"] != null && (string)Session["role"] == "admin")
            {
                int adminId = (int)Session["id"];

                User checkUser = (from m in db.User where m.email == a.emailId select m).SingleOrDefault();
                Admin checkAdmin = (from m in db.Admin where m.emailId == a.emailId && m.adminId!= adminId select m).SingleOrDefault();

                if (checkUser == null && checkAdmin == null)
                {
                    Admin updateAdmin = (from m in db.Admin where m.adminId == adminId select m).SingleOrDefault();

                    updateAdmin.name = a.name;
                    updateAdmin.emailId = a.emailId;
                    updateAdmin.branch = a.branch;
                    updateAdmin.sem = a.sem;
                    db.SaveChanges();

                    Session["name"] = updateAdmin.name;
                    Session["email"] = updateAdmin.emailId;
                }
                else
                {
                    ViewBag.updateStatus = "EmailId already registered!";
                }

                ViewBag.admin = (from m in db.Admin where m.adminId == adminId select m).SingleOrDefault();

                return View();
                //Response.Redirect("/User/Profile"); //Back to GET
            }

            else
            {
                Response.Redirect("/Login/Index");
                return View();
            }
        }
    }
}