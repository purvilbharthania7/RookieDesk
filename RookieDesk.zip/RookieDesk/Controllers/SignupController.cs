﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RookieDesk.Models;
namespace RookieDesk.Controllers
{
    public class SignupController : Controller
    {
        RookieDeskContext db = new RookieDeskContext();
        // GET: Signup
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(User u)
        {
            User checkUser = (from m in db.User where m.email == u.email select m).SingleOrDefault();
            Admin checkAdmin = (from m in db.Admin where m.emailId == u.email select m).SingleOrDefault();

            if (checkUser != null || checkAdmin != null)
            {
                ViewBag.signupStatus = "EmailId already registered!";
                return View();
            }

            db.User.Add(u);
            db.SaveChanges();
            Response.Redirect("/Login/Index");
            return View();
        }
    }
}