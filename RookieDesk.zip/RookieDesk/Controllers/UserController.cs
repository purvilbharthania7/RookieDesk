﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RookieDesk.Models;

namespace RookieDesk.Controllers
{
    public class UserController : Controller
    {
        RookieDeskContext db = new RookieDeskContext();
        // GET: Question
        public ActionResult Index()
        {
            if (Session["id"] != null && (string)Session["role"] == "user")
                return View(db.Questions.OrderByDescending(m => m.questionId).ToList());

            Response.Redirect("/Login/Index");
            return View();
        }

        [HttpPost]
        public void Index(Question q)
        {
            if (Session["id"] != null && (string)Session["role"] == "user")
            {
                q.userId = (int)Session["id"];
                db.Questions.Add(q);
                db.SaveChanges();

                Response.Redirect("/User/Index");
            }
            else
            {
                Response.Redirect("/Login/Index");
            }
        }

        public ActionResult MyQuestions()
        {
            if (Session["id"] != null && (string)Session["role"] == "user")
            {
                int userId = (int)Session["id"];
                return View("Index", db.Questions.Where(m => m.userId==userId).OrderByDescending(k => k.questionId).ToList());  
            }

            Response.Redirect("/Login/Index");
            return View();
        }

        public ActionResult Profile()
        {
            if (Session["id"] != null && (string)Session["role"] == "user")
            {
                int userId = (int)Session["id"];

                ViewBag.user = (from m in db.User where m.userId == userId select m).SingleOrDefault();

                return View();
            }

            Response.Redirect("/Login/Index");
            return View();
        }
        
        [HttpPost]
        public ActionResult Profile(User u)
        {

            if (Session["id"] != null && (string)Session["role"] == "user")
            {
                int userId = (int)Session["id"];

                User checkUser = (from m in db.User where m.email == u.email && m.userId != userId select m).SingleOrDefault();
                Admin checkAdmin = (from m in db.Admin where m.emailId == u.email select m).SingleOrDefault();

                if (checkUser == null && checkAdmin == null)
                {
                    User updateUser = (from m in db.User where m.userId == userId select m).SingleOrDefault();

                    updateUser.name = u.name;
                    updateUser.email = u.email;
                    updateUser.branch = u.branch;
                    updateUser.sem = u.sem;
                    db.SaveChanges();

                    Session["name"] = updateUser.name;
                    Session["email"] = updateUser.email;
                }
                else
                {
                    ViewBag.updateStatus = "EmailId already registered!";
                }

                ViewBag.user = (from m in db.User where m.userId == userId select m).SingleOrDefault();

                return View();
            }

            else
            {
                Response.Redirect("/Login/Index");
                return View();
            }
        }
    }
}