﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace RookieDesk.Models
{
    
    public class RookieDeskContext : DbContext
    {
        public RookieDeskContext():base("RookieDeskDb")
        {

        }

        public DbSet<User> User { get; set; }
        public DbSet<Admin> Admin { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Answer> Answers { get; set; }
        public DbSet<Blocked> Blocked { get; set; }
    }
}