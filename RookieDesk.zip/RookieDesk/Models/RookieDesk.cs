﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RookieDesk.Models
{
    public class RookieDesk
    {
        
    }

    public class User
    {
        public int userId { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string name { get; set; }
        public string branch { get; set; }
        public int sem { get; set; }
        
        public virtual ICollection<Question> Question { get; set; }
    }

    public class Question
    {
        
        public int questionId { get; set; }
        public int userId { get; set; }
        public string question { get; set; }
        
        public virtual User User { get; set; }

        public virtual ICollection<Answer> Answer { get; set; }
    }

    public class Admin
    {
        //[Key]
        public int adminId { get; set; }
        public string emailId { get; set; }
        public string password { get; set; }
        public string name { get; set; }
        public string branch { get; set; }
        public int sem { get; set; }

        public virtual ICollection<Answer> Answer { get; set; }
    }

    public class Answer
    {
        public int answerId { get; set; }
        public int adminId { get; set; }
        public int questionId { get; set; }
        public string answer { get; set; }
        public int votes { get; set; }

        public virtual Question Question { get; set; }

        public virtual Admin Admin { get; set; }
    }

    public class Blocked
    {
        public int blockedId { get; set; }
        public int userId { get; set; }
        public long timeStamp { get; set; }

        public virtual ICollection<User> User { get; set; }
    }
}